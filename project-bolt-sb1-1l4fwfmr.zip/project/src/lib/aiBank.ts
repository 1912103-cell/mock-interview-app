import type { ExamId } from './exams';

interface AiQuestion {
  text: string;
  followups: string[];
}

const BANK: Record<ExamId, AiQuestion[]> = {
  upsc: [
    {
      text: "Let's begin. What do you understand by the term 'inclusive governance', and why is it important for a diverse country like India?",
      followups: [
        "That's a fair start. Can you cite one recent government initiative that reflects inclusive governance and evaluate its impact?",
        "Good. Now, how would you balance fiscal discipline with welfare spending during an economic slowdown?",
      ],
    },
  ],
  'ssc-cgl': [
    {
      text: "Welcome. Tell me about yourself and why you chose to apply for this position through the SSC CGL route.",
      followups: [
        "Interesting. A train travels 600 km in 8 hours partly at 75 km/h and partly at 100 km/h. How much distance does it cover at each speed?",
        "Well attempted. How would you prioritise a high-volume data entry task with a tight deadline?",
      ],
    },
  ],
  'sbi-po': [
    {
      text: "Good to have you here. What is the current repo rate, and how does a change in it affect a bank's lending decisions?",
      followups: [
        "Reasonable. If a customer with a strong CIBIL score is denied a loan, how would you handle their grievance as a probationary officer?",
        "Good. Explain the difference between NPAs and write-offs, and why the distinction matters for a public sector bank.",
      ],
    },
  ],
  ssb: [
    {
      text: "Welcome, candidate. Describe a situation where you led a team under pressure. What was the outcome and what did you learn?",
      followups: [
        "Noted. You have a river to cross, one boat that holds two people, and four members of different weights. How do you plan the crossing efficiently?",
        "Good reasoning. If a subordinate disobeys your order during a critical operation, how do you respond in the moment and afterwards?",
      ],
    },
  ],
};

export function getOpeningQuestion(examId: ExamId): string {
  return BANK[examId][0].text;
}

export function getNextQuestion(
  examId: ExamId,
  exchangeCount: number
): string | null {
  const exam = BANK[examId][0];
  if (exchangeCount < exam.followups.length) {
    return exam.followups[exchangeCount];
  }
  return null;
}
